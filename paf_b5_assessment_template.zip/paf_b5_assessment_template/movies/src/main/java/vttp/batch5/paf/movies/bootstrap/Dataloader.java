package vttp.batch5.paf.movies.bootstrap;

public class Dataloader {

  //TODO: Task 2


}
