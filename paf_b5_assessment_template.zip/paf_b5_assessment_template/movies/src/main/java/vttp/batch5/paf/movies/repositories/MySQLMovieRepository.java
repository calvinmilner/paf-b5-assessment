package vttp.batch5.paf.movies.repositories;


public class MySQLMovieRepository {

  // TODO: Task 2.3
  // You can add any number of parameters and return any type from the method
  public void batchInsertMovies() {
   
  }
  
  // TODO: Task 3


}
